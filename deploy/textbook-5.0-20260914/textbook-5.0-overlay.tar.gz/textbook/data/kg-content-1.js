/* ============================================================
 * 离散数学 · 知识图谱内容数据（第1部分：C01-C03）
 * analog：学科应用 | explain：核心讲解 | chain：可视化思维链
 * questions：分层习题（level: 基础/进阶/挑战；from: 训练题库/教材自拟）
 * ============================================================ */
window.KG_CONTENT = window.KG_CONTENT || {};
Object.assign(window.KG_CONTENT, {

/* ============ 第1章 集合 ============ */
'S0101': {
  analog: '集合就是程序中的「数据类型实例」：一个变量能装的所有合法值的集合，比如布尔类型 = {true, false}，8位无符号整数类型 = {0,1,…,255}。',
  kps: {
    'K010101': {
      analog: '元素属于集合，就像「对象属于一个类」或「键存在于一个 Set 中」：$a \\in A$ 等价于 Set 的 has(a) 返回 true。',
      explain: '**集合：**指一些确定对象的整体，是离散数学的基础载体。\n\n**元素与集合的关系：**元素与集合之间只有两种关系，即属于（$a\\in A$）与不属于（$a\\notin A$）。\n\n**集合的表示法：**列举法，如 $A=\\{1,2,3\\}$；描述法，如 $B=\\{x|x\\in\\mathbb{Z}, x>0\\}$。\n\n**集合的三大特征：**确定性（可判定）、互异性（元素不重复）、无序性（顺序无关）。',
      chain: ['确定研究对象，用大写字母命名集合、小写字母命名元素', '判断研究对象是否满足集合的定义条件，决定是否纳入集合', '选择表示法：有限集用列举法，无限集或条件集用描述法', '验证集合的三大特征：确定性（可判定）、互异性（元素不重复）、无序性（顺序无关）']
    },
    'K010102': {
      analog: '子集关系就是类型兼容性：`unsigned int` 是 `int` 的「真子集」——凡 unsigned int 的值必是 int 的值，反之不然。',
      explain: '**子集：**若集合 $B$ 的所有元素都属于 $A$，则称 $B$ 是 $A$ 的子集，记作 $B\\subseteq A$。\n\n**真子集：**若 $B\\subseteq A$ 且 $A\\not\\subseteq B$，则称 $B$ 是 $A$ 的真子集。\n\n**空集与全集：**空集 $\\varnothing$ 是任何集合的子集；全集 $E$ 包含所讨论的所有对象。\n\n**集合相等：**两个集合相等当且仅当互为子集，即 $A=B \\Leftrightarrow A\\subseteq B \\land B\\subseteq A$。',
      chain: ['由定义：$B\\subseteq A$ 当且仅当 $\\forall x(x\\in B \\to x\\in A)$', '证明相等时用双向包含：先证 $A\\subseteq B$，再证 $B\\subseteq A$', '空集判定的关键：$\\varnothing\\subseteq A$ 恒成立（因为空集中无元素可举反例）', '举例验证：$\\varnothing \\in \\{\\varnothing\\}$ 但 $\\varnothing \\notin \\varnothing$，区分「属于」与「包含」']
    },
    'K010103': {
      analog: '幂集就是「枚举一个集合的全部子集」，与回溯算法枚举子集、位掩码枚举（$2^n$ 种状态）完全同构。',
      explain: '**m 元子集与子集计数：**含有 $n$ 个元素的集合称作 $n$ 元集，其含 $m\\ (m\\le n)$ 个元素的子集称作 $m$ 元子集；$n$ 元集的 $m$ 元子集共有 $\\binom{n}{m}$ 个。\n\n**幂集：**集合 $A$ 的幂集 $P(A)$ 是 $A$ 的所有子集构成的集合。\n\n**幂集的基数：**若 $|A|=n$，则 $|P(A)|=2^n$，因为每个元素都有「选入子集 / 不选」两种状态，对应二进制位掩码的 $2^n$ 种组合。\n\n**空集的幂集：**$\\{\\varnothing\\}$，含有 1 个元素。',
      chain: ['列出集合 $A$ 的所有元素，$n$ 个元素', '每个元素对应 1 个二进制位（1=选入子集，0=不选）', '遍历 0 到 $2^n-1$ 的 $n$ 位二进制数，逐位生成子集', '把生成的 $2^n$ 个子集装进集合，得到 $P(A)$']
    }
  },
  questions: [
    { level:'基础', pointId:'P01010103', from:'教材自拟', kpName:'集合的表示法', q:'用列举法表示集合 $A=\\{x|x\\in\\mathbb{N},\\ 1<x<6\\}$，并求 $|P(A)|$。', a:'$A=\\{2,3,4,5\\}$，$|A|=4$，故 $|P(A)|=2^4=16$。', explain:'描述法转列举法：先确定 x 的取值范围为自然数，再筛选满足不等式的值；幂集个数由公式 $|P(A)|=2^{|A|}$ 直接给出。' },
    { level:'进阶', pointId:'P01010203', from:'训练题库·模拟2', kpName:'集合的相等', q:'考虑下述集合：$A=\\{3,4\\}$，$B=\\{4,3\\}\\cup\\varnothing$，$C=\\{4,3\\}\\cup\\{\\varnothing\\}$，$D=\\{x\\in\\mathbb{R}\\mid x^2-7x+12=0\\}$，$E=\\{\\varnothing,3,4\\}$，$F=\\{4,4,3\\}$，$G=\\{4,\\varnothing,\\varnothing,3\\}$。那么其中相等的集合是 ______。', a:'$A=B=D=F$，$C=E=G$', explain:'判断集合相等依据元素是否相同：$\\varnothing\\cup B=B$，而 $\\{\\varnothing\\}$ 是含空集的集合；$\\{4,4,3\\}$ 因互异性等于 $\\{3,4\\}$。' },
    { level:'挑战', pointId:'P01010302', from:'教材自拟', kpName:'幂集的基数', q:'设 $|A|=n$。用组合数学的观点解释为什么 $|P(A)|=2^n$，并写出 $|P(P(A))|$。', a:'$P(A)$ 中每个子集对应一个 $n$ 位 0/1 向量（第 i 位表示第 i 个元素是否入选），共 $2^n$ 种。故 $|P(P(A))|=2^{2^n}$。', explain:'幂集元素数是一个递归的指数结构，也是「子集个数」组合恒等式 $\\sum_{k=0}^{n}\\binom{n}{k}=2^n$ 的来源。' }
  ]
},
'S0102': {
  analog: '并、交、补运算就是 SQL/集合框架中的 UNION、INTERSECT、EXCEPT；对称差相当于 XOR（异或）运算。',
  kps: {
    'K010201': {
      analog: '并集=OR、交集=AND、补集=NOT，对称差=XOR，逻辑运算与集合运算通过「特征函数」一一对应。',
      explain: '**并集：**$A\\cup B=\\{x|x\\in A\\lor x\\in B\\}$。\n\n**交集：**$A\\cap B=\\{x|x\\in A\\land x\\in B\\}$。\n\n**相对补集：**$A-B=\\{x|x\\in A\\land x\\notin B\\}$。\n\n**不交集合与 n 元并交：**若 $A\\cap B=\\varnothing$，则称 $A$、$B$ 不交；两个集合的并、交可分别推广到 $n$ 个集合：$A_1\\cup\\cdots\\cup A_n$ 与 $A_1\\cap\\cdots\\cap A_n$。\n\n**对称差：**$A\\oplus B=(A-B)\\cup(B-A)$，也可等价地定义为 $A\\oplus B=(A\\cup B)-(A\\cap B)$。\n\n**绝对补集：**在给定全集 $E$ 后，$\\sim A=E-A=\\{x|x\\in E\\land x\\notin A\\}$。',
      chain: ['确定全集 E 与集合 A、B 的元素', '并集：取至少属于一个集合的元素（逻辑或）', '交集：取同时属于两个集合的元素（逻辑与）', '对称差：取恰好属于其中一个集合的元素（异或）']
    },
    'K010202': {
      analog: '广义并/广义交就是 reduce 操作：Python 的 `set().union(*集族)` 与 `set(集族的交)`，先取元素再逐层合并。',
      explain: '**集族：**由集合构成的集合称为集族，用花体大写字母 $\\mathcal{A}$ 表示；上文的并、交称为初级并、初级交。\n\n**广义并（定义 1.2.4）：**$\\cup\\mathcal{A}=\\{x\\mid \\exists A\\in\\mathcal{A}\\text{ 使得 }x\\in A\\}$。若 $\\mathcal{A}=\\{A_1,\\dots,A_n\\}$，则 $\\cup\\mathcal{A}=A_1\\cup\\dots\\cup A_n$。\n\n**广义交（定义 1.2.5）：**对非空集族 $\\mathcal{A}$，$\\cap\\mathcal{A}=\\{x\\mid \\forall A\\in\\mathcal{A}\\text{ 均有 }x\\in A\\}$；同样有 $\\cap\\mathcal{A}=A_1\\cap\\dots\\cap A_n$（空族的广义交另有约定）。\n\n**集合运算的优先顺序：**一类运算（绝对补、幂集、广义并/交）优先于二类运算（相对补、对称差、初级并/交）；一类运算自右向左，二类运算按括号、无括号时从左到右。',
      chain: ['把 n 个集合编号为 A1,A2,…,An', '广义并：对所有元素判断是否存在 i 使 x∈Ai', '广义交：对所有元素判断是否 ∀i 都有 x∈Ai', '注意与 n=2 的情形一致，验证特例']
    }
  },
  questions: [
    { level:'基础', pointId:'P01020101', from:'教材自拟', kpName:'并交补运算', q:'设 $A=\\{1,2,3,4\\}$，$B=\\{3,4,5\\}$，全集 $E=\\{1,2,3,4,5,6\\}$。求 $A\\cup B$、$A\\cap B$、$A-B$、$\\sim A$。', a:'$A\\cup B=\\{1,2,3,4,5\\}$；$A\\cap B=\\{3,4\\}$；$A-B=\\{1,2\\}$；$\\sim A=\\{5,6\\}$。', explain:'逐一定义展开：并取两集并集、交取公共元素、差取属于 A 不属于 B 的元素、补取全集减去 A。' },
    { level:'进阶', pointId:'P01020102', from:'训练题库·模拟1', kpName:'集合等式与充要条件', q:'求下列集合等式成立的充分必要条件：$(A-C)\\cup B=A\\cup B$。', a:'条件为 $A\\cap C\\subseteq B$。充分性容易验证。必要性：$(A-C)\\cup B=A\\cup B \\Leftrightarrow A\\cap C\\subseteq (A-C)\\cup B \\Rightarrow A\\cap C\\subseteq B$。', explain:'这类题把等式的两边看成集合，利用并、差、交的运算性质逐步化简，最后归结为包含关系。' },
    { level:'挑战', pointId:'P01020103', from:'教材自拟', kpName:'对称差', q:'证明对称差运算满足结合律：$(A\\oplus B)\\oplus C=A\\oplus(B\\oplus C)$。', a:'利用对称差与特征函数的关系：令 $\\chi_A,\\chi_B,\\chi_C$ 为特征函数（取 0/1），则 $\\chi_{A\\oplus B}=\\chi_A\\oplus\\chi_B$（模2加法）。$(\\chi_A\\oplus\\chi_B)\\oplus\\chi_C=\\chi_A\\oplus(\\chi_B\\oplus\\chi_C)$，模2加法结合，故等式成立。', explain:'对称差对应 XOR，特征函数法把集合等式转化为 0/1 代数运算，是「归约法」的典型应用。' }
  ]
},
'S0103': {
  analog: '集合算律就是「代码重构中的等价变换规则」，如布尔短路求值：`a && (b || a) == a`（吸收律）。',
  kps: {
    'K010301': {
      analog: '德摩根律对应逻辑中的 `!(A&&B) == !A || !B`，编译器做条件化简时就依赖这些规则。',
      explain: '**幂等律：**$A\\cup A=A$，$A\\cap A=A$。\n\n**结合律：**$(A\\cup B)\\cup C=A\\cup(B\\cup C)$，$(A\\cap B)\\cap C=A\\cap(B\\cap C)$。\n\n**交换律：**$A\\cup B=B\\cup A$，$A\\cap B=B\\cap A$。\n\n**分配律：**$A\\cup(B\\cap C)=(A\\cup B)\\cap(A\\cup C)$，$A\\cap(B\\cup C)=(A\\cap B)\\cup(A\\cap C)$。\n\n**同一律：**$A\\cup\\varnothing=A$，$A\\cap E=A$。\n\n**零律：**$A\\cup E=E$，$A\\cap\\varnothing=\\varnothing$。\n\n**排中律：**$A\\cup\\sim A=E$。\n\n**矛盾律：**$A\\cap\\sim A=\\varnothing$。\n\n**吸收律：**$A\\cup(A\\cap B)=A$，$A\\cap(A\\cup B)=A$。\n\n**德摩根律：**$\\sim(A\\cup B)=\\sim A\\cap\\sim B$，$\\sim(A\\cap B)=\\sim A\\cup\\sim B$。\n\n**双重否定律：**$\\sim(\\sim A)=A$。',
      chain: ['对照式 (1.3.1)~式 (1.3.23) 记住每条算律的名称与形式', '把集合运算翻译成并、交、补的逻辑联结词', '成对记忆：并↔交、$E$↔$\\varnothing$ 互为对偶', '代入具体集合验证两边元素完全相同']
    },
    'K010302': {
      analog: '证明集合算律类似于「用规范化规则证明两段代码等价」，每一步都是可验证的机械变换。',
      explain: '**命题逻辑法（归入谓词逻辑）：**把 $x\\in A$ 看成命题 $P$，把集合运算翻译成逻辑联结词，借助逻辑等值式证明；具体操作上就是验证等式左右互相包含。',
      chain: ['任取元素 x，把 x∈左边 翻译为逻辑命题', '用逻辑等值式（分配律、德摩根律等）化简', '把化简结果翻译回集合语言，得到 x∈右边', '由 x 的任意性，两边互为子集，等式得证']
    },
    'K010303': {
      analog: '已知算律代入化简＝用已证定理替换子表达式：不改变语义，只把式子逐步改写成目标形式。',
      explain: '**集合恒等式化简法：**利用已知的恒等式来代入，逐步把左边化简为右边（如例 1.3.3 由式 (1.3.1)~式 (1.3.14) 推证吸收律 (1.3.15)）。\n\n**集合运算的基本性质：**$A\\cap B\\subseteq A$，$A\\cap B\\subseteq B$，$A\\subseteq A\\cup B$，$B\\subseteq A\\cup B$，$A-B=A\\cap\\sim B$；更一般地 $A\\cup B=B\\Leftrightarrow A\\subseteq B\\Leftrightarrow A\\cap B=A\\Leftrightarrow A-B=\\varnothing$。\n\n**包含互推法：**分别证明 $A\\subseteq B$ 与 $B\\subseteq A$ 两个方向，从而 $A=B$（如例 1.3.4、例 1.3.6）。\n\n**对称差的性质：**$A\\oplus A=\\varnothing$，$A\\oplus\\varnothing=A$，$A\\oplus B=B\\oplus A$，满足结合律，并有消去律 $A\\oplus B=A\\oplus C\\Rightarrow B=C$（如例 1.3.8）。',
      chain: ['列出题目允许使用的已知算律与运算性质', '把待证式中的子表达式按算律等价替换', '反复代入化简，直到化为目标形式', '需要时改用包含互推法，分两个方向证明']
    }
  },
  questions: [
    { level:'基础', pointId:'P01030110', from:'教材自拟', kpName:'德摩根律', q:'化简：$\\sim((A\\cap B)\\cup C)$，其中 $\\sim$ 表示全集 E 下的补集。', a:'$\\sim((A\\cap B)\\cup C)=\\sim(A\\cap B)\\cap\\sim C=(\\sim A\\cup\\sim B)\\cap\\sim C$。', explain:'连续使用德摩根律：外层取补对并集取反，内层再对交集取反，注意补集嵌套顺序。' },
    { level:'进阶', pointId:'P01030303', from:'教材自拟', kpName:'包含互推法', q:'用包含互推法证明分配律：$A\\cup(B\\cap C)=(A\\cup B)\\cap(A\\cup C)$。', a:'先证 $\\subseteq$：任取 $x\\in A\\cup(B\\cap C)$，分 $x\\in A$ 或 $x\\in B\\cap C$ 两类，均可得 $x\\in(A\\cup B)\\cap(A\\cup C)$。再证 $\\supseteq$：任取 $x\\in(A\\cup B)\\cap(A\\cup C)$，若 $x\\in A$ 已得证；否则 $x\\in B$ 且 $x\\in C$，故 $x\\in B\\cap C$。双向包含得证。', explain:'包含互推法的核心是分类讨论 + 定义展开，是证明集合等式最通用的方法。' },
    { level:'挑战', pointId:'P01030201', from:'训练题库·模拟2', kpName:'集合算律证明', q:'设 $A,B,C$ 为集合，证明：$A\\cap(B-C)=(A-C)\\cap(B-C)$。', a:'$(A-C)\\cap(B-C)=(A\\cap\\sim C)\\cap(B\\cap\\sim C)=A\\cap B\\cap\\sim C=A\\cap(B-C)$。', explain:'把差运算写成交集补的形式，利用交集结合律化简，一步到位。' }
  ]
},
'S0104': {
  analog: '容斥原理就是「去重计数」：统计多个分类的总数时，先全加，再减去重复计数的部分——与 UV 去重、SQL 多表 JOIN 去重的思想一致。',
  kps: {
    'K010402': {
      analog: '文氏图就是集合的「可视化示意图」：把集合画成平面区域、运算结果涂成阴影，一眼就能看出每块区域的元素归属。',
      explain: '**文氏图（Venn diagram）：**用平面上的区域表示集合，以阴影区域表示运算结果，可直观描述集合之间的关系和初级运算（图 1.4.1）。\n\n**用文氏图分析集合关系：**把已知条件标注到各块区域上，设未知量并列方程组求解（如例 1.4.1 的外语掌握情况调查）。\n\n**用文氏图计数：**把待计数的对象按性质划分成若干互不重叠的区域，逐块统计后汇总（如例 1.4.2 中 1~1000 之间不能被 5、6、8 整除的数的个数）。\n\n**注意：**文氏图是分析与计数工具，严格论证仍需回到定义与算律。',
      chain: ['画出全集 E 的矩形与各集合对应的圆', '先把已知的交集（含三者公共部分）区域填好', '由「各集合总数 − 交集」得到只属于该集合的区域', '用全集总数补出圈外区域，汇总所求']
    },
    'K010401': {
      analog: '容斥公式（两集合情形）$|A\\cup B|=|A|+|B|-|A\\cap B|$ 对应「两个列表合并去重」：先相加，再减去交集重复部分。',
      explain: '**容斥公式（两集合）：**$|A\\cup B|=|A|+|B|-|A\\cap B|$。\n\n**容斥公式（三集合）：**$|A\\cup B\\cup C|=|A|+|B|+|C|-|A\\cap B|-|A\\cap C|-|B\\cap C|+|A\\cap B\\cap C|$。\n\n一般地，**容斥公式（n 集合，加法形式）：**$|A_1\\cup A_2\\cup\\cdots\\cup A_n|=\\sum_{i=1}^{n}|A_i|-\\sum_{1\\le i<j\\le n}|A_i\\cap A_j|+\\sum_{1\\le i<j<k\\le n}|A_i\\cap A_j\\cap A_k|-\\cdots+(-1)^{n-1}|A_1\\cap A_2\\cap\\cdots\\cap A_n|$。\n\n若 $S$ 为全集，$A_i$ 表示 $S$ 中具有性质 $P_i$ 的元素集，则 $S$ 中不具有任何性质的元素数**（容斥公式的减法形式）：**$|\\overline{A_1}\\cap\\overline{A_2}\\cap\\cdots\\cap\\overline{A_n}|=|S|-\\sum_{i=1}^{n}|A_i|+\\sum_{1\\le i<j\\le n}|A_i\\cap A_j|-\\cdots+(-1)^{n}|A_1\\cap A_2\\cap\\cdots\\cap A_n|$。\n\n**文氏图**可以直观看出每块区域被加减的次数，加奇减偶，恰好多算一次的部分被扣除。\n\n',
      chain: ['把要求的事件分解为若干集合的并', '先对所有集合大小求和（多算了交集部分）', '减去所有两两交集的贡献', '若集合数≥3，加回三三交集，依此类推（奇加偶减）']
    }
  },
  questions: [
    { level:'基础', pointId:'P01040203', from:'教材自拟', kpName:'文氏图计数', q:'某班40人，会游泳的25人，会骑车的20人，两样都会的10人。用文氏图求只会游泳、只会骑车以及两样都不会的人数。', a:'只会游泳 $25-10=15$ 人；只会骑车 $20-10=10$ 人；两样都不会 $40-(15+10+10)=5$ 人。', explain:'把全集画成矩形、两个集合画成相交的圆，先填交叠区域（两样都会＝10），再用各集合总数减去交叠区域得到「只会」区域，最后用全集总数补出圈外区域。' },
    { level:'基础', pointId:'P01040101', from:'教材自拟', kpName:'容斥公式', q:'某班级50人，选 Python 课的有28人，选数据库课的有20人，两门都选的有8人。问至少选了一门课的人数。', a:'$|A\\cup B|=28+20-8=40$ 人。', explain:'两集合容斥公式直接代入。' },
    { level:'进阶', pointId:'P01040101', from:'教材自拟', kpName:'容斥公式', q:'在1到100的整数中，能被2或3或5整除的数有多少个？', a:'$\\lfloor100/2\\rfloor+\\lfloor100/3\\rfloor+\\lfloor100/5\\rfloor-\\lfloor100/6\\rfloor-\\lfloor100/10\\rfloor-\\lfloor100/15\\rfloor+\\lfloor100/30\\rfloor=50+33+20-16-10-6+3=74$。', explain:'把「被2整除」「被3整除」「被5整除」三个集合分别计数，再用三集合容斥修正。' },
    { level:'挑战', pointId:'P01040101', from:'训练题库·模拟1', kpName:'容斥公式', q:'设 $S=\\{2\\cdot a_1, 2\\cdot a_2, \\cdots, 2\\cdot a_k\\}$ 是多重集，如果在 $S$ 的全排列中相同的两个 $a_i$ 不相邻，问这样的全排列有多少个。', a:'令 $A_i$ 为含相邻 $a_i$ 的排列集，$|A|=\\frac{(2k)!}{2^k}$，$|A_i|=\\frac{(2k-1)!}{2^{k-1}}$，$|A_{i_1}\\cap\\cdots\\cap A_{i_r}|=\\frac{(2k-r)!}{2^{k-r}}$，由容斥原理所求为 $\\sum_{r=0}^{k}(-1)^r\\binom{k}{r}\\frac{(2k-r)!}{2^{k-r}}$。', explain:'这是容斥原理在排列计数中的经典应用：先把「某两个相同元素相邻」看作一个整体压缩，再用容斥扣除。' }
  ]
},

/* ============ 第2章 关系 ============ */
'S0201': {
  analog: '有序对就是结构体/元组 `(x, y)`，笛卡儿积就是两层 for 循环生成的全部组合：`[(x,y) for x in A for y in B]`。',
  kps: {
    'K020101': {
      analog: '有序对 <a,b> 相当于数组下标 [0] 和 [1]：两个位置区分前后，`<a,b>=<c,d>` 要求对应位置分别相等。',
      explain: '**有序对：**$\\langle a,b\\rangle$ 强调次序，是两个分量的有序组合，与无序集合不同。\n\n**有序对相等的充要条件：**$\\langle a,b\\rangle=\\langle c,d\\rangle \\Leftrightarrow a=c \\land b=d$，即两个分量分别相等。\n\n注意 $\\langle a,b\\rangle=\\langle b,a\\rangle$ 当且仅当 $a=b$。有序对是关系的载体，关系本身就是有序对的集合。',
      chain: ['明确有序对的两个分量及其顺序', '相等判定：第一分量相等且第二分量相等', '与无序对 {a,b} 对比：无序对不考虑顺序', '用有序对构造关系：关系 R = 某些有序对的集合']
    },
    'K020102': {
      analog: '笛卡儿积 $A\\times B$ 就是外键 JOIN：主表的每个记录都与从表的每条记录配对一次。',
      explain: '**笛卡儿积：**$A\\times B=\\{\\langle x,y\\rangle|x\\in A\\land y\\in B\\}$，即由 $A$ 中元素作第一分量、$B$ 中元素作第二分量的全部有序对构成的集合，$|A\\times B|=|A|\\cdot|B|$。\n\n**笛卡儿积对并、交的分配律：**$A\\times(B\\cup C)=(A\\times B)\\cup(A\\times C)$。\n\n**$A\\times B$ 与 $B\\times A$ 的区别：**一般 $A\\times B\\neq B\\times A$（除非 $A=B$ 或某集合为空），因为分量次序不同导致集合不同。',
      chain: ['取出 A 中第一个元素，依次与 B 中每个元素配对', '取出 A 中第二个元素，继续配对，直至穷举', '把所有有序对收集为集合，即 A×B', '验证乘法法则：元素个数 = |A|·|B|']
    }
  },
  questions: [
    { level:'基础', pointId:'P02010201', from:'教材自拟', kpName:'笛卡儿积', q:'设 $A=\\{1,2\\}$，$B=\\{a,b,c\\}$。求 $A\\times B$ 与 $B\\times A$，并指出 $|A\\times B|$。', a:'$A\\times B=\\{\\langle1,a\\rangle,\\langle1,b\\rangle,\\langle1,c\\rangle,\\langle2,a\\rangle,\\langle2,b\\rangle,\\langle2,c\\rangle\\}$，$|A\\times B|=6$。$B\\times A=\\{\\langle a,1\\rangle,\\langle b,1\\rangle,\\langle c,1\\rangle,\\langle a,2\\rangle,\\langle b,2\\rangle,\\langle c,2\\rangle\\}$。', explain:'笛卡儿积保持第一分量来自 A、第二分量来自 B，顺序不同则集合不同。' },
    { level:'进阶', pointId:'P02010202', from:'教材自拟', kpName:'笛卡儿积分配律', q:'证明：$A\\times(B\\cap C)=(A\\times B)\\cap(A\\times C)$。', a:'任取 $\\langle x,y\\rangle\\in A\\times(B\\cap C)\\Leftrightarrow x\\in A\\land y\\in B\\cap C\\Leftrightarrow x\\in A\\land y\\in B\\land y\\in C\\Leftrightarrow \\langle x,y\\rangle\\in A\\times B\\land\\langle x,y\\rangle\\in A\\times C\\Leftrightarrow \\langle x,y\\rangle\\in(A\\times B)\\cap(A\\times C)$。', explain:'双向推导都用「当且仅当」，本质是逻辑联结词的分配。' },
    { level:'挑战', pointId:'P02010102', from:'教材自拟', kpName:'有序对与笛卡儿积', q:'证明：若 $A\\times B=A\\times C$ 且 $A\\neq\\varnothing$，则 $B=C$。', a:'任取 $y\\in B$，取定 $x\\in A$，则 $\\langle x,y\\rangle\\in A\\times B=A\\times C$，故 $y\\in C$，即 $B\\subseteq C$；同理 $C\\subseteq B$，所以 $B=C$。', explain:'关键步骤是利用 $A\\neq\\varnothing$ 取一个固定元素作为「探针」，把第二分量的元素提取出来。' }
  ]
},
'S0202': {
  analog: '二元关系就是「两个集合元素之间的配对规则」，可以建模为：邻接矩阵、邻接表（关系图）、或一条条记录（关系数据库表）。',
  kps: {
    'K020201': {
      analog: '关系矩阵就是布尔矩阵：第 i 行第 j 列取 1 表示 $\\langle a_i,b_j\\rangle\\in R$——等价于二维数组/位图。',
      explain: '**二元关系的集合定义：**集合 $A$ 到 $B$ 的二元关系 $R$ 是 $A\\times B$ 的子集：$R\\subseteq A\\times B$。\n\n**关系矩阵：**$M_R$ 中 $m_{ij}=1$ 当且仅当 $\\langle a_i,b_j\\rangle\\in R$，行表示第一分量、列表示第二分量，用 0/1 填表。\n\n**关系图：**顶点表示元素，有向边 $a\\to b$ 表示 $\\langle a,b\\rangle\\in R$。\n\n关系的三种表示法（集合表达式、关系矩阵、关系图）本质相同，可以相互转化。',
      chain: ['确定论域 A、B，写出 A×B', '按规则筛选出属于关系 R 的有序对', '用矩阵：行=第一分量，列=第二分量，1/0 填表', '或用关系图：画顶点，连有向边']
    },
    'K020202': {
      analog: '特殊关系 = 关系里的「标准件」：空关系不含任何有序对、全域关系含全部有序对、恒等关系只含对角线上的有序对。',
      explain: '**空关系：**空集 $\\varnothing$ 不含任何有序对，是任何集合上的关系。\n\n**全域关系：**$E_A=A\\times A$，含 $A$ 上全部有序对。\n\n**恒等关系：**$I_A=\\{\\langle x,x\\rangle|x\\in A\\}$，只含对角线上的有序对。空、全域、恒等三种关系分别对应布尔矩阵的全 0、全 1 与单位阵。',
      chain: ['给定集合 A 与关系 R', 'R 不含任何有序对 → 空关系', 'R 含 A×A 的全部有序对 → 全域关系', 'R 恰为 {⟨x,x⟩|x∈A} → 恒等关系']
    }
  },
  questions: [
    { level:'基础', pointId:'P02020101', from:'教材自拟', kpName:'关系的集合表示', q:'设 $A=\\{1,2,3\\}$，$R=\\{\\langle x,y\\rangle|x,y\\in A, x<y\\}$。写出 R 的集合表达式和关系矩阵。', a:'$R=\\{\\langle1,2\\rangle,\\langle1,3\\rangle,\\langle2,3\\rangle\\}$，矩阵 $\\begin{pmatrix}0&1&1\\\\0&0&1\\\\0&0&0\\end{pmatrix}$。', explain:'按 x<y 筛选 A×A 中的有序对，再映射为矩阵。' },
    { level:'进阶', pointId:'P02020102', from:'教材自拟', kpName:'关系矩阵与关系图', q:'设 $A=\\{1,2,3\\}$，$R$ 是 $A$ 上的关系，其关系矩阵 $M_R$ 的第 1、3 行都是 $1\\ 0\\ 1$，第 2 行是 $0\\ 1\\ 0$。写出 $R$ 的集合表达式，画出 $R$ 的关系图，并判断 $R$ 是否为空关系、全域关系或恒等关系。', a:'$R=\\{\\langle1,1\\rangle,\\langle1,3\\rangle,\\langle2,2\\rangle,\\langle3,1\\rangle,\\langle3,3\\rangle\\}$，共 5 个有序对。关系图：顶点取 $1,2,3$，$1$ 与 $3$ 之间为双向边，另有 $1\\to1$、$2\\to2$、$3\\to3$ 三个自环。判别：$R\\neq\\varnothing$；$R\\neq E_A$（缺 $\\langle1,2\\rangle$、$\\langle2,1\\rangle$、$\\langle2,3\\rangle$、$\\langle3,2\\rangle$）；$R\\neq I_A$（含 $\\langle1,3\\rangle,\\langle3,1\\rangle$），故 $R$ 只是一般的二元关系。', explain:'矩阵第 $i$ 行第 $j$ 列为 1 等价于 $\\langle a_i,a_j\\rangle\\in R$：逐行读出有序对即得集合表达式，对角线上的 1 表示自环。空关系、全域关系、恒等关系的矩阵分别是全 0 阵、全 1 阵与单位阵，对照即可判别。' },
    { level:'挑战', pointId:'P02020201', from:'教材自拟', kpName:'关系的计数与特殊关系', q:'设 $A=\\{1,2,3\\}$。$A$ 上一共可以定义多少个二元关系？其中空关系、全域关系、恒等关系各有几个？并说明这三种关系对应的关系矩阵各有什么特征。', a:'$|A\\times A|=3\\times3=9$，而 $A$ 上的关系就是 $A\\times A$ 的子集，故共有 $2^9=512$ 个。空关系 1 个，矩阵为全 0 阵；全域关系 1 个（$E_A=A\\times A$），矩阵为全 1 阵；恒等关系 1 个（$I_A=\\{\\langle1,1\\rangle,\\langle2,2\\rangle,\\langle3,3\\rangle\\}$），矩阵为单位阵（对角线为 1、其余为 0）。', explain:'关系的计数归结为子集计数：$n$ 元集上一共有 $2^{n^2}$ 个二元关系，因为每个有序对都有「属于 / 不属于」两种选择。给定 $A$ 后三种特殊关系唯一确定，分别对应布尔矩阵的全 0、全 1 与单位阵。' }
  ]
},
'S0203': {
  analog: '关系的运算：求域（投影出 dom/ran）、限制与像（过滤起点取终点）、求逆（交换分量）、复合（两步跳转）与幂（多跳可达），把二元关系当作可加工的数据表。',
  kps: {
    'K020305': {
      analog: '关系的域 = 给二元关系做「投影」：所有第一分量构成定义域 dom R，所有第二分量构成值域 ran R，类似 SQL 对某一列做 SELECT DISTINCT。',
      explain: '**关系的域（定义2.3.1）：**设 $R$ 是二元关系。$R$ 中所有有序对的第一元素构成的集合称为 $R$ 的定义域，记作 $\\text{dom}\\,R=\\{x\\mid\\exists y\\ \\langle x,y\\rangle\\in R\\}$；所有有序对的第二元素构成的集合称为 $R$ 的值域，记作 $\\text{ran}\\,R=\\{y\\mid\\exists x\\ \\langle x,y\\rangle\\in R\\}$；$\\text{dom}\\,R\\cup\\text{ran}\\,R$ 称为 $R$ 的域，记作 $\\text{fld}\\,R$。如例2.3.1 中 $R=\\{\\langle1,2\\rangle,\\langle1,3\\rangle,\\langle2,4\\rangle,\\langle4,1\\rangle\\}$，则 $\\text{dom}R=\\{1,2,4\\}$，$\\text{ran}R=\\{1,2,3,4\\}$。',
      chain: ['扫描 R 的全部有序对', '取各有序对的第一分量并去重 → dom R', '取各有序对的第二分量并去重 → ran R', 'dom R 与 ran R 之并即 R 的域']
    },
    'K020302': {
      analog: '复合运算 $S\\circ R$（或 $R\\circ S$）对应矩阵乘法（布尔代数下），也就是 SQL 自连接找中间人。',
      explain: '**复合关系：**$R\\circ S=\\{\\langle x,z\\rangle|\\exists y(\\langle x,y\\rangle\\in R\\land\\langle y,z\\rangle\\in S)\\}$，即存在中间元素 $y$ 使 $x$ 经 $R$ 到 $y$、$y$ 经 $S$ 到 $z$。\n\n**结合律：**复合运算满足结合律：$(R\\circ S)\\circ T=R\\circ(S\\circ T)$。\n\n**矩阵形式：**复合对应布尔矩阵乘法：$(M_{R\\circ S})_{ij}=\\bigvee_{k=1}^{n}\\big((M_R)_{ik}\\land(M_S)_{kj}\\big)$，其中 $n$ 为中间集合的元素个数（$R\\subseteq A\\times B$、$S\\subseteq B\\times C$ 时 $n=|B|$）。',
      chain: ['给出 R 与 S 的集合或矩阵', '对每个候选 x,z 寻找中间元素 y', '存在 y 使 ⟨x,y⟩∈R 且 ⟨y,z⟩∈S，则 ⟨x,z⟩∈R∘S', '用布尔矩阵乘法验证：相乘-取或（AND-OR）']
    },
    'K020301': {
      analog: '逆关系就是「反转边」：图的有向边全部反向，或数据库记录的主外键互换。',
      explain: '**逆关系：**$R^{-1}=\\{\\langle y,x\\rangle|\\langle x,y\\rangle\\in R\\}$，即把每个有序对的两个分量交换。\n\n**逆运算的性质：**$(R^{-1})^{-1}=R$，$(R\\circ S)^{-1}=S^{-1}\\circ R^{-1}$（注意次序反转）。\n\n**矩阵形式：**$M_{R^{-1}}$ 是 $M_R$ 的转置。',
      chain: ['把 $R$ 中每个有序对 $\\langle x,y\\rangle$ 的分量交换', '得到 $\\langle y,x\\rangle$ 的集合 $R^{-1}$', '复合的逆：先逆 $S$ 再逆 $R$ 且次序交换', '用矩阵转置验证']
    },
    'K020303': {
      analog: '关系的 n 次幂就是图上「走 n 步可达」的关系：$R^n$ 的元素对应长度为 n 的通路。',
      explain: '**关系的幂：**$R^0=I_A$（恒等关系），$R^{n+1}=R^n\\circ R$。\n\n**幂与复合的关系：**$\\langle x,y\\rangle\\in R^n$ 当且仅当在关系图中存在从 $x$ 到 $y$ 的长度为 $n$ 的通路。\n\n**矩阵形式：**$M_{R^n}=(M_R)^n$（布尔幂）。',
      chain: ['定义 $R^0$ = 恒等关系（0 步可达）', '$R^1=R$（1 步）', '$R^n=R^{n-1}\\circ R$（$n$ 步 = 先走 $n-1$ 步再走 1 步）', '矩阵逐次自乘（布尔乘法）求 $M_{R^n}$']
    },
    'K020304': {
      analog: '限制 = 按起点集合过滤关系；像 = 过滤后那些有序对的「终点」集合——好比先按主键集合筛选记录、再投影取某列。',
      explain: '**限制与像（定义2.3.4）：**设 $R$ 为二元关系、$A$ 为集合。$R$ 在 $A$ 上的限制 $R\\restriction A=\\{\\langle x,y\\rangle\\,|\\,\\langle x,y\\rangle\\in R\\land x\\in A\\}$，即仅保留起点在 $A$ 中的有序对；$A$ 在 $R$ 下的像 $R[A]=\\mathrm{ran}(R\\restriction A)$，即这些有序对的第二分量组成的集合。\n\n**基本事实：**$R\\restriction A$ 是 $R$ 的子关系；若 $A\\subseteq B$，则 $R\\restriction A\\subseteq R\\restriction B$。\n\n**并/交性质（定理2.3.5）：**① $F\\restriction(A\\cup B)=F\\restriction A\\cup F\\restriction B$；② $F[A\\cup B]=F[A]\\cup F[B]$；③ $F\\restriction(A\\cap B)=F\\restriction A\\cap F\\restriction B$；④ $F[A\\cap B]\\subseteq F[A]\\cap F[B]$。即限制对并、交均可分配，像对并分配、对交仅为子集包含。',
      chain: ['给定关系 R 与集合 A', '限制：筛出起点在 A 内的有序对，得 R↾A', '像：R[A]=ran(R↾A)，取这些有序对的终点', '对并/交套用定理 2.3.5 的四条公式']
    }
  },
  questions: [
    { level:'基础', pointId:'P02030201', from:'教材自拟', kpName:'关系的复合', q:'设 $A=\\{1,2,3\\}$，$R=\\{\\langle1,2\\rangle,\\langle2,3\\rangle\\}$，$S=\\{\\langle2,1\\rangle,\\langle3,2\\rangle\\}$。求 $R\\circ S$ 与 $S\\circ R$。', a:'$R\\circ S=\\{\\langle1,1\\rangle,\\langle2,2\\rangle\\}$；$S\\circ R=\\{\\langle2,2\\rangle,\\langle3,3\\rangle\\}$。', explain:'按定义 $R\\circ S=\\{\\langle x,z\\rangle|\\exists y(\\langle x,y\\rangle\\in R\\land\\langle y,z\\rangle\\in S)\\}$：$\\langle1,2\\rangle\\in R$ 且 $\\langle2,1\\rangle\\in S$ 给出 $\\langle1,1\\rangle$，$\\langle2,3\\rangle\\in R$ 且 $\\langle3,2\\rangle\\in S$ 给出 $\\langle2,2\\rangle$。$S\\circ R$ 同理先看 S 再看 R。$R\\circ S\\neq S\\circ R$，说明复合不满足交换律。' },
    { level:'进阶', pointId:'P02030501', from:'教材自拟', kpName:'关系的域', q:'设 $R=\\{\\langle1,2\\rangle,\\langle1,3\\rangle,\\langle2,4\\rangle,\\langle4,1\\rangle\\}$。求 dom R、ran R，以及 $R\\restriction\\{1,2\\}$（R 在 {1,2} 上的限制）。', a:'$\\text{dom}R=\\{1,2,4\\}$，$\\text{ran}R=\\{1,2,3,4\\}$，$R\\restriction\\{1,2\\}=\\{\\langle1,2\\rangle,\\langle1,3\\rangle,\\langle2,4\\rangle\\}$。', explain:'限制运算保留第一分量属于给定集合的那些有序对。' },
    { level:'进阶', pointId:'P02030101', from:'教材自拟', kpName:'关系的逆', q:'设 $R=\\{\\langle1,2\\rangle,\\langle2,3\\rangle,\\langle3,1\\rangle\\}$。求 $R^{-1}$ 及 $(R\\circ R)^{-1}$，并验证 $(R\\circ R)^{-1}=(R^{-1})\\circ(R^{-1})$。', a:'$R^{-1}=\\{\\langle2,1\\rangle,\\langle3,2\\rangle,\\langle1,3\\rangle\\}$；$R\\circ R=\\{\\langle1,3\\rangle,\\langle2,1\\rangle,\\langle3,2\\rangle\\}$，$(R\\circ R)^{-1}=\\{\\langle3,1\\rangle,\\langle1,2\\rangle,\\langle2,3\\rangle\\}$；$R^{-1}\\circ R^{-1}=\\{\\langle3,1\\rangle,\\langle1,2\\rangle,\\langle2,3\\rangle\\}$，一致。', explain:'逆的复合满足反转律，与矩阵转置的乘积顺序一致。' },
    { level:'挑战', pointId:'P02030302', from:'教材自拟', kpName:'关系的幂', q:'设 $R=\\{\\langle1,2\\rangle,\\langle2,1\\rangle,\\langle2,3\\rangle\\}$。求 $R^2$、$R^3$，并说明 $R^2$ 中每个元素对应的通路长度。', a:'$R^2=\\{\\langle1,1\\rangle,\\langle1,3\\rangle,\\langle2,2\\rangle\\}$；$R^3=\\{\\langle1,2\\rangle,\\langle2,1\\rangle,\\langle2,3\\rangle\\}$。$R^2$ 中 $\\langle1,3\\rangle$ 对应通路 1→2→3（长度2），$\\langle1,1\\rangle$ 对应 1→2→1；$R^3$ 中 $\\langle2,3\\rangle$ 对应 2→1→2→3（长度3）。', explain:'矩阵布尔幂与通路计数一致：$R^n$ 的第 (i,j) 项为 1 当且仅当存在长度 n 的通路从 i 到 j。' }
  ]
},
'S0204': {
  analog: '关系的四种性质对应程序中的「比较语义」：自反(=有自环)、对称(=无向边)、反对称(=有向且无双向)、传递(=可传递比较)。',
  kps: {
    'K020401': {
      analog: '自反性像 `<=`：每个元素都和自己有关系（x<=x 恒真）；反自反性像 `<`：每个元素都不与自己有关系。',
      explain: '**自反性：**$\\forall x\\in A$，$\\langle x,x\\rangle\\in R$，即每个元素都与自身有关系（矩阵主对角线全 1，图中每个顶点有环）。\n\n**反自反性：**$\\forall x\\in A$，$\\langle x,x\\rangle\\notin R$，即每个元素都不与自身有关系（主对角线全 0）。\n\n注意自反与反自反不是「非此即彼」的关系，一个关系可以二者皆非。',
      chain: ['检查主对角线：是否全 1（自反）或全 0（反自反）', '检查关系图：每个顶点是否有环', '注意自反与反自反不是「非此即彼」：可二者皆非', '举例：整除关系自反，严格小于关系反自反']
    },
    'K020402': {
      analog: '对称性像「双向好友」：有关系就是互相认识；反对称像「单向关注」：不能互相关注（除非是同一人）。',
      explain: '**对称性：**$\\langle x,y\\rangle\\in R\\Rightarrow\\langle y,x\\rangle\\in R$，即关系成对出现（矩阵对称，图中边成对反向）。\n\n**反对称性：**$\\langle x,y\\rangle\\in R\\land\\langle y,x\\rangle\\in R\\Rightarrow x=y$，即不允许两条相反方向的边同时存在。\n\n注意对称与反对称可以同时成立（如恒等关系 $I_A$ 既对称又反对称）。',
      chain: ['取任意 ⟨x,y⟩∈R，检查 ⟨y,x⟩ 是否也必在 R', '对称：矩阵沿主对角线对称；图边成对', '反对称：检查矩阵是否 $m_{ij}\\cdot m_{ji}=0$（$i\\neq j$）', '特例：恒等关系既对称又反对称']
    },
    'K020403': {
      analog: '传递性像「闭包运算」：a→b 且 b→c 则必有 a→c，类似类型系统里的传递类型关系。',
      explain: '**传递性：**$\\langle x,y\\rangle\\in R\\land\\langle y,z\\rangle\\in R\\Rightarrow\\langle x,z\\rangle\\in R$。\n\n**等价条件：**$R\\circ R\\subseteq R$，即所有「两跳可达」都已经是直达边。',
      chain: ['用复合判定：计算 R∘R', '检查是否 R∘R ⊆ R（即所有两跳可达都在 R 中）', '逐条验证：∀⟨x,y⟩,⟨y,z⟩∈R 推出 ⟨x,z⟩∈R', '反例构造：找到一对「两跳但无直达」即可否定传递性']
    },
    'K020404': {
      analog: '判定定理=「不用逐项验证，只查恒等关系与逆关系」：把 5 种性质翻译成集合恒等式，一眼看穿。',
      explain: '**定理 2.4.1（判定定理）：**设 $R$ 是 $A$ 上的关系，$I_A$ 为恒等关系，则\n\n(1) $R$ 自反 $\\Leftrightarrow I_A\\subseteq R$；\n\n(2) $R$ 反自反 $\\Leftrightarrow R\\cap I_A=\\varnothing$；\n\n(3) $R$ 对称 $\\Leftrightarrow R=R^{-1}$；\n\n(4) $R$ 反对称 $\\Leftrightarrow R\\cap R^{-1}\\subseteq I_A$。\n\n**作用：**把「逐项验证」化为集合（或矩阵）运算，判定关系性质更高效率；例 2.4.4 就是用这些恒等式证明具体关系的性质。',
      chain: ['写出恒等关系 I_A 与逆关系 R⁻¹', '自反 ⟺ I_A ⊆ R；反自反 ⟺ R∩I_A=∅', '对称 ⟺ R=R⁻¹；反对称 ⟺ R∩R⁻¹ ⊆ I_A', '在矩阵上：R⁻¹ 即转置，比较矩阵即可完成判定']
    },
    'K020405': {
      analog: '性质「看得见」：关系矩阵的对角线与对称性、关系图的自环与反向边——性质就是图形特征。',
      explain: '**表 2.4.1（矩阵与图特征）：**\n\n自反：主对角线全为 1；关系图每个顶点都有自环。\n\n反自反：主对角线全为 0；图中无自环。\n\n对称：矩阵关于主对角线对称（$m_{ij}=m_{ji}$）；图中边成对反向出现。\n\n反对称：$i\\neq j$ 时 $m_{ij}$ 与 $m_{ji}$ 不同时为 1；图中任意两点间至多一条有向边。\n\n传递：$M_R^2\\le M_R$（逐项比较）；图中任意两步通路都有直达边。\n\n**例 2.4.5：**给定关系图，按上述特征逐条比对即可判定全部性质。',
      chain: ['看主对角线：全 1 则自反，全 0 则反自反', '看矩阵对称性 ⟹ 对称；看 i≠j 处是否同时为 1 ⟹ 反对称', '算 M² 与 M 逐项比较 ⟹ 传递性', '回到关系图复核：自环、成对反向边、两步通路']
    },
    'K020406': {
      analog: '性质与运算的「兼容表」：并、交、补、逆运算后哪些性质保留、哪些丢失——像一张运算反应性对照表。',
      explain: '**表 2.4.2（性质与运算的联系）：**\n\n可保持：逆关系 $R^{-1}$ 保持自反、反自反、对称、反对称、传递全部五种性质；$R\\cup R^{-1}$ 一定对称；$R\\cap R^{-1}$ 既对称又反对称。\n\n一般不可保持：并、交、差（补）、复合运算不保持全部性质。反例：$R=\\{\\langle1,2\\rangle\\}$、$S=\\{\\langle2,3\\rangle\\}$ 都传递，但 $R\\cup S$ 不传递（缺 $\\langle1,3\\rangle$）。\n\n**用途：**遇到「运算后是否仍具有某性质」的判断，可先查表，再用反例否定。',
      chain: ['明确面对的运算：并、交、差、逆还是复合', '逐一对照表 2.4.2 的保持情况', '反例否定：一对传递关系的并可能破坏传递性', '结论：该性质在运算下「保持」或「不保持」']
    }
  },
  questions: [
    { level:'基础', pointId:'P02040101', from:'教材自拟', kpName:'关系性质判定', q:'设 $A=\\{1,2,3\\}$，$R=\\{\\langle1,1\\rangle,\\langle2,2\\rangle,\\langle1,2\\rangle,\\langle2,1\\rangle\\}$。判断 R 是否自反、对称、传递。', a:'不自反（缺 ⟨3,3⟩）；对称（⟨1,2⟩ 与 ⟨2,1⟩ 成对）；传递（需验证，成立）。', explain:'逐一检查定义：自反要求每个元素都有自环；对称要求成对；传递检查两跳可达。' },
    { level:'进阶', pointId:'P02040201', from:'训练题库·模拟1', kpName:'反对称关系证明', q:'设 $R,S$ 为非空集合 $A$ 上的反对称关系，证明：$R\\cap S$ 也是 $A$ 上的反对称关系。', a:'任取 $\\langle x,y\\rangle$，若 $\\langle x,y\\rangle\\in R\\cap S$ 且 $\\langle y,x\\rangle\\in R\\cap S$，则 $\\langle x,y\\rangle\\in R$ 且 $\\langle y,x\\rangle\\in R$。因为 R 反对称，所以 $x=y$。故 $R\\cap S$ 反对称。', explain:'交运算保持反对称性：只需利用 R 自身的反对称性即可推出 x=y。' },
    { level:'挑战', pointId:'P02040501', from:'教材自拟', kpName:'关系矩阵与传递性判定', q:'设 $A=\\{1,2,3,4\\}$，$R=\\{\\langle1,2\\rangle,\\langle2,3\\rangle,\\langle1,3\\rangle,\\langle3,4\\rangle,\\langle1,4\\rangle,\\langle2,4\\rangle\\}$。R 是否传递？若是，说明理由；若否，指出缺失的元素。', a:'传递。任意两跳组合：1→2→3 有 1→3；1→2→4 有 1→4；1→3→4 有 1→4；2→3→4 有 2→4，全部覆盖。', explain:'传递性需穷举所有「两跳路径」验证，可用矩阵 $M_R^2\\le M_R$（逐项比较）快速判断。' }
  ]
},
'S0205': {
  analog: '闭包就是「补全操作」：把关系图中缺失的自环/反向边/间接可达边补齐到满足某性质，类似求传递闭包做可达性分析。',
  kps: {
    'K020501': {
      analog: '自反闭包=给每个顶点补自环；对称闭包=把每条边补成双向；传递闭包=把所有间接可达变直达。',
      explain: '**闭包的定义：**闭包是包含 $R$ 且满足对应性质的最小超关系。\n\n**自反闭包：**$r(R)=R\\cup I_A$。\n\n**对称闭包：**$s(R)=R\\cup R^{-1}$。\n\n**传递闭包：**$t(R)=R\\cup R^2\\cup R^3\\cup\\cdots$，有穷集上只需加到 $R^n$。',
      chain: ['明确要满足的性质（自反/对称/传递）', '自反闭包：∪ 恒等关系（补对角线）', '对称闭包：∪ 逆关系（补反向边）', '传递闭包：∪ 各次幂（补两跳、三跳…直达边）']
    },
    'K020502': {
      analog: 'Warshall 算法就是「动态规划求传递闭包」：依次允许每个顶点作为中间点，逐步扩展可达集合。',
      explain: '**公式法：**$r(R)=R\\cup I_A$，$s(R)=R\\cup R^{-1}$，$t(R)=\\bigcup_{i=1}^{n}R^i$。\n\n**Warshall 算法：**对矩阵 $M$，依次让每个顶点作为中间点，若第 $k$ 行为 1 的行，把第 $k$ 行的 1 复制到该行，逐步扩展可达集合，复杂度 $O(n^3)$，与 Floyd 算法思想一致。\n\n**关系图法：**在关系图中把所有能到达的间接边补成直达边。',
      chain: ['写出 R 的矩阵 M', '自反闭包：对角线置 1', '对称闭包：M 与其转置取或', '传递闭包（Warshall）：三重循环，k 从 1 到 n，若 M[i][k]=1 则把 M[k] 行并入 M[i] 行']
    },
    'K020503': {
      analog: '闭包的性质=「够不够格」：已经满足某性质的关系，其对应闭包就是它自己——像已排序的数组再排一次不变。',
      explain: '**与性质的等价刻画（定理 2.5.2）：**$r(R)=R\\Leftrightarrow R$ 自反；$s(R)=R\\Leftrightarrow R$ 对称；$t(R)=R\\Leftrightarrow R$ 传递。\n\n**单调性与幂等性（定理 2.5.3）：**若 $R_1\\subseteq R_2$，则 $r(R_1)\\subseteq r(R_2)$、$s(R_1)\\subseteq s(R_2)$、$t(R_1)\\subseteq t(R_2)$；且三种闭包都幂等（$r(r(R))=r(R)$ 等）。\n\n**性质在闭包下的保持（定理 2.5.4）：**$R$ 自反 $\\Rightarrow s(R)$、$t(R)$ 自反；$R$ 对称 $\\Rightarrow r(R)$、$t(R)$ 对称；$R$ 传递 $\\Rightarrow r(R)$ 传递。',
      chain: ['检验「闭包 = 原关系」是否成立 ⟺ 已具该性质', '比较两个关系：子集关系在闭包运算下保持（单调）', '重复求闭包不再变化（幂等性）', '由单项性质推出复合闭包的性质（定理 2.5.4）']
    },
    'K020504': {
      analog: '自反、对称、传递闭包=「一次补齐三种性质」：先补自环，再补反向边，最后补可达边。',
      explain: '**三种性质与闭包的联动（定理 2.5.4 总结）：**\n\n- $R$ 自反时：$s(R)$、$t(R)$ 都自反，且 $r(R)=R$；\n- $R$ 对称时：$r(R)$、$t(R)$ 都对称；\n- $R$ 传递时：$t(R)=R$，且 $r(R)$ 仍传递。\n\n**用途：**已知 $R$ 已有某项性质时，可直接断定闭包结果的性质，省去重复验证；也说明求闭包的先后顺序不影响最终结果的性质集合。',
      chain: ['先看 R 已具有哪些性质', '自反 ⇒ 对称闭包、传递闭包仍自反', '对称 ⇒ 自反闭包、传递闭包仍对称', '传递 ⇒ 传递闭包即自身，只需补自环维持传递']
    }
  },
  questions: [
    { level:'基础', pointId:'P02050101', from:'教材自拟', kpName:'自反与对称闭包', q:'设 $A=\\{1,2,3\\}$，$R=\\{\\langle1,2\\rangle,\\langle2,3\\rangle\\}$。求 $r(R)$、$s(R)$。', a:'$r(R)=\\{\\langle1,2\\rangle,\\langle2,3\\rangle,\\langle1,1\\rangle,\\langle2,2\\rangle,\\langle3,3\\rangle\\}$；$s(R)=\\{\\langle1,2\\rangle,\\langle2,1\\rangle,\\langle2,3\\rangle,\\langle3,2\\rangle\\}$。', explain:'r(R) 补自环，s(R) 补反向边。' },
    { level:'进阶', pointId:'P02050203', from:'训练题库·模拟3', kpName:'三种闭包的矩阵求法', q:'设 R 的关系图如图所示。（1）说明 R 的性质；（2）求 $R^2$；（3）求 $r(R),s(R),t(R)$ 的关系矩阵。', a:'（1）R 不具有任何性质。（2）$R^2=\\{\\langle1,2\\rangle,\\langle1,4\\rangle,\\langle2,2\\rangle,\\langle2,4\\rangle,\\langle3,3\\rangle,\\langle3,4\\rangle\\}$。（3）$M_r=\\begin{pmatrix}1&0&1&1\\\\0&1&1&1\\\\0&1&1&1\\\\0&0&0&1\\end{pmatrix}$，$M_s=\\begin{pmatrix}1&0&1&1\\\\0&0&1&1\\\\1&1&0&1\\\\1&1&1&0\\end{pmatrix}$，$M_t=\\begin{pmatrix}0&1&1&1\\\\0&1&1&1\\\\0&1&1&1\\\\0&0&0&0\\end{pmatrix}$。', explain:'本题图对应的矩阵为 $M_R=\\begin{pmatrix}0&0&1&1\\\\0&0&1&1\\\\0&1&0&1\\\\0&0&0&0\\end{pmatrix}$，三种闭包分别补对角线、补反向边、补传递可达。' },
    { level:'挑战', pointId:'P02050202', from:'教材自拟', kpName:'Warshall算法', q:'用 Warshall 算法求 $R=\\{\\langle1,2\\rangle,\\langle2,3\\rangle,\\langle3,1\\rangle\\}$ 的传递闭包矩阵。', a:'$M=\\begin{pmatrix}0&1&0\\\\0&0&1\\\\1&0&0\\end{pmatrix}$。k=1：M[3][1]=1，把第1行并入第3行得 $\\begin{pmatrix}0&1&0\\\\0&0&1\\\\1&1&0\\end{pmatrix}$；k=2：M[1][2]=1 并入第1行，M[3][2]=1 并入第3行；k=3：逐行并入第3行。最终 $t(R)$ 为全 1 矩阵（强连通），即 $t(R)=A\\times A$。', explain:'该关系构成 1→2→3→1 的循环，任意两点互相可达，传递闭包为全域关系。' }
  ]
},
'S0206': {
  analog: '等价关系=「按某种属性归类」，等价类=哈希表的桶，商集=去重后的类型分组。DFA 状态最小化就靠它。',
  kps: {
    'K020601': {
      analog: '「同余」是等价关系：「模 3 相同」把所有整数分成 3 个桶；「哈希值相同」把对象分组。',
      explain: '**等价关系：**同时满足自反、对称、传递的关系。\n\n**等价类：**$[x]_R=\\{y|\\langle x,y\\rangle\\in R\\}$，是互不相交且覆盖全集的子集族。\n\n**商集：**$A/R=\\{[x]_R|x\\in A\\}$ 是全体等价类的集合。',
      chain: ['验证 R 的自反、对称、传递性', '任取元素 x，收集与 x 等价的元素构成等价类 [x]', '验证不同等价类不相交、全体等价类覆盖 A', '商集 = 所有等价类组成的集合 A/R']
    },
    'K020602': {
      analog: '划分就是把集合切分成「互不相交且并起来是全集」的若干块，等价于数据表按键分组。',
      explain: '**划分：**集合 $A$ 的划分 $\\pi$ 是一族非空子集，满足：任意两个不同块不相交，且所有块的并等于 $A$。\n\n**等价关系与划分的一一对应：**一个等价关系唯一确定一个划分（即等价类族），反之一个划分也唯一确定一个等价关系（同块则相关）。',
      chain: ['给定等价关系 R，求等价类族', '验证等价类两两不交、并集为 A', '得到划分 π = A/R', '反过来：给定划分 π，定义 x~y ⟺ x、y 同块，验证其为等价关系']
    }
  },
  questions: [
    { level:'基础', pointId:'P02060101', from:'教材自拟', kpName:'等价类与商集', q:'设 $A=\\{1,2,3,4,5,6\\}$，R 为「模 3 同余」关系：$\\langle x,y\\rangle\\in R\\Leftrightarrow 3\\mid(x-y)$。求等价类与商集。', a:'$[1]_R=[4]_R=\\{1,4\\}$，$[2]_R=[5]_R=\\{2,5\\}$，$[3]_R=[6]_R=\\{3,6\\}$；$A/R=\\{\\{1,4\\},\\{2,5\\},\\{3,6\\}\\}$。', explain:'模运算同余是等价关系，等价类按余数划分。' },
    { level:'进阶', pointId:'P02060202', from:'训练题库·模拟2', kpName:'等价关系与划分', q:'设 $A=\\{1,2,3\\}$，R 为 $A\\times A$ 上的等价关系：$\\langle\\langle a,b\\rangle,\\langle c,d\\rangle\\rangle\\in R\\Leftrightarrow ab=cd$。（1）设 I 为恒等关系，求 $R-I$；（2）求 R 对应的 $A\\times A$ 的划分 $\\pi$。', a:'（1）$R-I=\\{\\langle\\langle1,2\\rangle,\\langle2,1\\rangle\\rangle,\\langle\\langle2,1\\rangle,\\langle1,2\\rangle\\rangle,\\langle\\langle1,3\\rangle,\\langle3,1\\rangle\\rangle,\\langle\\langle3,1\\rangle,\\langle1,3\\rangle\\rangle,\\langle\\langle2,3\\rangle,\\langle3,2\\rangle\\rangle,\\langle\\langle3,2\\rangle,\\langle2,3\\rangle\\rangle\\}$。（2）$\\pi=\\{\\{\\langle1,2\\rangle,\\langle2,1\\rangle\\},\\{\\langle1,3\\rangle,\\langle3,1\\rangle\\},\\{\\langle2,3\\rangle,\\langle3,2\\rangle\\},\\{\\langle1,1\\rangle\\},\\{\\langle2,2\\rangle\\},\\{\\langle3,3\\rangle\\}\\}$。', explain:'按乘积 ab=cd 把 9 个有序对分组：乘积为 2、3、6、1、4、9 六组，得到划分。' },
    { level:'挑战', pointId:'P02060201', from:'训练题库·模拟4', kpName:'划分与等价关系', q:'$R$ 为自然数集 $\\mathbb{N}$ 上的关系，$\\forall x,y\\in\\mathbb{N}$，$xRy\\Leftrightarrow 2\\mid(x+y)$，则 R 对应的 $\\mathbb{N}$ 的划分是 ______。', a:'$A=\\{2x\\mid x\\in\\mathbb{N}\\}$，划分 $\\mathbb{N}/R=\\{A,\\mathbb{N}-A\\}$（即奇偶两类）。', explain:'x+y 为偶数当且仅当 x、y 同奇偶，故划分为偶数集与奇数集。' }
  ]
},
'S0207': {
  analog: '偏序关系=「层级/优先级」关系，哈斯图=去掉冗余箭头的依赖图（如软件模块的依赖层级、进程调度优先级）。',
  kps: {
    'K020701': {
      analog: '偏序集类似「部分有序的任务图」：有些任务可比（有依赖），有些不可比（可并行）。DAG 拓扑排序正是偏序的线性扩展。',
      explain: '**偏序关系：**自反、反对称、传递的关系，记作 $\\preceq$；偏序集记为 $\\langle A,\\preceq\\rangle$。\n\n**哈斯图：**偏序集的简化图：省略自环、省略由传递性保证的边，且自下而上排列。\n\n**全序关系：**若偏序集中任意两元素都可比，则称全序。',
      chain: ['给出偏序集 ⟨A, ≼⟩', '画哈斯图：顶点表元素，覆盖关系画边，下小上大', '判断可比性：两元素间是否有链相连', '全序判定：任意两元素都可比']
    },
    'K020702': {
      analog: '极大元=「没有上级的模块」，最大元=「唯一的顶级模块」，上界=「所有可比元素的共同祖先」。',
      explain: '**极大元与极小元：**极大元是「没有元素大于它」（但可能与其他元素不可比）；极小元是「没有元素小于它」。\n\n**最大元与最小元：**最大元大于等于所有元素，最小元小于等于所有元素，都具有唯一性。\n\n**上界、下界与上下确界：**上界是大于等于子集所有元素的元素，最小上界（上确界）是其中最小者；下界与下确界同理。\n\n极大元与最大元不同：最大元必是极大元，反之不然（存在多个不可比元素时可有多个极大元）。',
      chain: ['列出 A 的所有元素', '找极大元：不存在 y≠x 使 x≼y', '找最大元：∀y 有 y≼x（唯一性）', '对子集 B：找上界集，再取其中最小者（若存在）为上确界']
    },
    'K020703': {
      analog: '调度问题=「按依赖关系排任务」：把任务集与先后约束看成偏序集，求满足约束的加工顺序——如流水线排产、编译模块的构建顺序。',
      explain: '**问题的形式化：**设任务集 $T=\\{t_1,t_2,\\ldots,t_n\\}$，配备 $m$ 台机器，任务间存在偏序（先后）约束 $\\preceq$。调度就是给每个任务安排一个开始时刻，使同一时刻一台机器至多执行一个任务，且 $t_i\\prec t_j$ 时 $t_i$ 先完成。\n\n**例 2.7.5：**给定 $m=2$ 与任务偏序集，先按哈斯图找出所有极小元（无前驱的任务）作为可并行开工的候选；每台机器每个时刻取一个可执行任务，执行完释放新任务，用「最小元素优先」规则逐步排出加工顺序。\n\n**单机与截止时间：**当 $m=1$ 且每个任务有截止时间时，按偏序的拓扑序尽早安排；判断能否按时完成（或在限定时间内完成全部任务所需的机器数）属于典型的偏序调度问题。',
      chain: ['写出任务集 T、机器数 m 与偏序约束', '画哈斯图，找极小元（可开工任务）', '每个时刻为每台机器指派一个极小元任务', '任务完成 → 释放其后继，重复直至全部排完']
    }
  },
  questions: [
    { level:'基础', pointId:'P02070101', from:'教材自拟', kpName:'偏序集与哈斯图', q:'设偏序集 $\\langle A,\\preceq\\rangle$，$A=\\{1,2,3,6,12\\}$，$\\preceq$ 为整除关系。画哈斯图并求极大元、最大元。', a:'哈斯图：1 在底部，2、3 在中间，6 之上是 12（12 与 2、3 传递）。极大元为 12，最大元为 12。', explain:'整除关系的哈斯图按「素因子层次」自底向上排列。' },
    { level:'进阶', pointId:'P02070201', from:'训练题库·模拟3', kpName:'极大元', q:'设偏序集 $\\langle A,\\mid\\rangle$，其中 $A=\\{2,3,4,\\cdots,1000\\}$，$\\mid$ 表示整除关系，那么该偏序集的所有极大元构成的集合是 ______。', a:'$\\{x\\in A\\mid 501\\leq x\\leq 1000\\}$', explain:'在 2..1000 中，极大元是那些不能被 2..1000 中其他数整除的数，即大于 500 的数（因为任何 ≤1000 的数的 2 倍 ≤1000 才能整除它）。' },
    { level:'挑战', pointId:'P02070202', from:'训练题库·模拟4', kpName:'偏序与最大元', q:'已知集合 A,B，$A\\neq\\varnothing$，$\\langle B,\\preceq\\rangle$ 是偏序集，定义 $B^A$ 上的二元关系 R：$fRg\\Leftrightarrow f(x)\\preceq g(x),\\ \\forall x\\in A$。给出 $\\langle B^A,R\\rangle$ 存在最大元的充分必要条件和最大元的一般形式。', a:'充要条件是偏序集 $\\langle B,\\preceq\\rangle$ 存在最大元。设 B 的最大元为 b，则 $B^A$ 上的最大元是常函数 $f(x)=b$。', explain:'逐点序下，函数 f 是最大元当且仅当每个取值都是 B 的最大元，故必须 B 有最大元且取常值。' }
  ]
},

/* ============ 第3章 函数 ============ */
'S0301': {
  analog: '函数就是「无副作用的一一映射」：每个输入恰好对应一个输出，等价于编程中的纯函数或哈希映射。',
  kps: {
    'K030101': {
      analog: '函数 $f:A\\to B$ 是满足「单值性」的关系：A 中每个元素恰有一个像，就像 `dict` 的键唯一。',
      explain: '**函数定义（单值约束）：**函数 $f$ 从 $A$ 到 $B$ 是 $A\\times B$ 上的二元关系，且满足：$\\forall x\\in A$，存在唯一的 $y\\in B$ 使 $\\langle x,y\\rangle\\in f$，记作 $f:A\\to B$，$y=f(x)$。\n\n**函数集合：**所有从 $A$ 到 $B$ 的函数全体记作 $B^A$，且有 $|B^A|=|B|^{|A|}$。',
      chain: ['确认 $f$ 是 $A\\times B$ 的子集', '检查单值性：$\\forall x\\in A$ 恰有一个像', '给出函数定义域 $A$、陪域 $B$ 与对应规则', '计数：函数个数 = $|B|^{|A|}$']
    },
    'K030102': {
      analog: '单射=「不丢信息的编码」，满射=「覆盖所有目标值」，双射=「可逆的完美映射」——如 JSON 序列化与反序列化互为双射。',
      explain: '**单射（一对一）：**$f(x_1)=f(x_2)\\Rightarrow x_1=x_2$，即不同输入对应不同输出。\n\n**满射（到上）：**$\\forall y\\in B$ 存在 $x\\in A$ 使 $f(x)=y$，即值域 $\\text{ran }f=B$。\n\n**双射：**既单射又满射。有限集上存在双射要求 $|A|=|B|$，此时 $|B|^{|A|}$ 个函数中恰有 $|A|!$ 个双射。',
      chain: ['单射检验：不同输入 → 不同输出（或反证：同输出推出同输入）', '满射检验：值域是否等于陪域 B', '双射 = 单射 ∧ 满射', '有限集情形：双射存在 ⟺ |A|=|B|，个数 = |A|!']
    },
    'K030103': {
      analog: '时间复杂度函数=「数基本运算次数」：把算法执行的次数表示为输入规模 n 的函数，用来比较算法快慢——如给算法「称重」。',
      explain: '**时间复杂度函数：**设算法处理的输入规模为 $n$，把算法中最基本的运算（如比较、赋值）的执行次数表示为 $n$ 的函数 $T(n)$，称为该算法的时间复杂度函数。\n\n**分治与二分搜索：**二分搜索每次把搜索区间对半缩小，比较次数约为 $\\lceil\\log_2(n+1)\\rceil$，明显优于顺序查找的 $n$ 次；分治策略的复杂度满足递推式 $T(n)=2T(n/2)+cn$，解得 $T(n)=O(n\\log n)$（如归并排序）。\n\n**函数阶的比较（例 3.1.8）：**常用函数按增长速度由小到大排列：$\\log n\\prec n\\prec n\\log n\\prec n^2\\prec n^3\\prec 2^n\\prec n!$，即 $\\log n=O(n)$、$n=O(n^2)$ 等，据此判断算法在大规模输入下的优劣。',
      chain: ['确定输入规模 n 与基本运算', '统计基本运算执行次数得到 T(n)', '化简为常见函数的阶（log n、n、n log n、n²…）', '比较不同算法的 T(n)，取增长更慢者']
    }
  },
  questions: [
    { level:'基础', pointId:'P03010201', from:'教材自拟', kpName:'单射满射判定', q:'设 $f:\\mathbb{Z}\\to\\mathbb{Z}$，$f(x)=2x$。判断 f 是否单射、满射。', a:'单射（$2x_1=2x_2\\Rightarrow x_1=x_2$）；不是满射（值域为偶数集，奇数值无原像）。', explain:'单射看能否由函数值反推自变量；满射看值域是否覆盖陪域。' },
    { level:'进阶', pointId:'P03010101', from:'训练题库·模拟3', kpName:'函数像与原像', q:'设 $f:\\mathbb{N}\\to\\mathbb{N}\\times\\mathbb{N}$，$f(x)=\\langle x,x^2\\rangle$。（1）求 $f(\\{1,2,3\\})$；（2）讨论 f 是否为单射或满射。', a:'（1）$f(\\{1,2,3\\})=\\{\\langle1,1\\rangle,\\langle2,4\\rangle,\\langle3,9\\rangle\\}$。（2）f 是单射（$\\langle x,x^2\\rangle$ 由第一分量唯一确定 x），不是满射（如 $\\langle1,2\\rangle\\notin\\text{ran}f$）。', explain:'函数像集是把定义域子集中每个元素求函数值后取并。' },
    { level:'挑战', pointId:'P03010203', from:'训练题库·模拟2', kpName:'构造双射', q:'构造从 A 到 B 的双射函数：（1）$A=\\mathbb{Z}$，$B=\\mathbb{N}$；（2）$A=[\\pi,2\\pi]$，$B=[-1,1]$。', a:'（1）$f(x)=\\begin{cases}2x,&x\\geq0\\\\-2x-1,&x<0\\end{cases}$（偶数对非负整数，奇数对负整数）。（2）$f(x)=\\cos x$。', explain:'整数集与自然数集等势的构造：把整数按 0,1,-1,2,-2… 的方式交错映射到自然数。' }
  ]
},
'S0302': {
  analog: '函数复合就是「管道流水线」：$g\\circ f$ = 先跑 f 再跑 g，像 Unix 管道的 `f | g`；反函数就是「撤销操作」。',
  kps: {
    'K030201': {
      analog: '复合函数 $g\\circ f(x)=g(f(x))$ 就是「先执行函数 f，再执行函数 g」——对应编程中的函数组合 compose(g, f)。',
      explain: '**复合定义：**复合函数 $g\\circ f:A\\to C$ 定义为 $(g\\circ f)(x)=g(f(x))$，要求 $\\text{ran }f\\subseteq\\text{dom }g$。\n\n**结合律：**复合运算满足结合律：$h\\circ(g\\circ f)=(h\\circ g)\\circ f$。\n\n**保持性质：**若 $f$、$g$ 均单射，则 $g\\circ f$ 单射；均满射则复合满射。',
      chain: ['确认 f 的输出类型与 g 的输入类型匹配', '先对 x 应用 f，得到中间值 y=f(x)', '再对 y 应用 g，得到 (g∘f)(x)=g(y)', '验证结合律：h∘(g∘f)=(h∘g)∘f']
    },
    'K030202': {
      analog: '反函数就是「撤销/逆操作」：加密函数的反函数是解密；只有双射（可逆编码）才有反函数。',
      explain: '**反函数定义：**若 $f:A\\to B$ 是双射，则存在反函数 $f^{-1}:B\\to A$，且满足 $f^{-1}\\circ f=I_A$，$f\\circ f^{-1}=I_B$。\n\n**存在条件：**$f$ 有反函数当且仅当 $f$ 是双射。\n\n**图像对称性：**反函数的图像关于 $y=x$ 对称。',
      chain: ['判断 $f$ 是否双射（单射+满射）', '双射 → 反函数存在', '求反函数：令 $y=f(x)$，反解 $x$ 关于 $y$ 的表达式', '验证 $f^{-1}(f(x))=x$ 与 $f(f^{-1}(y))=y$']
    }
  },
  questions: [
    { level:'基础', pointId:'P03020101', from:'教材自拟', kpName:'复合函数', q:'设 $f:\\mathbb{R}\\to\\mathbb{R}$，$f(x)=x+1$；$g:\\mathbb{R}\\to\\mathbb{R}$，$g(x)=x^2$。求 $g\\circ f$ 与 $f\\circ g$。', a:'$(g\\circ f)(x)=(x+1)^2$；$(f\\circ g)(x)=x^2+1$。两者不同，说明复合不满足交换律。', explain:'先内后外计算，复合顺序不可交换。' },
    { level:'进阶', pointId:'P03020201', from:'训练题库·模拟4', kpName:'反函数', q:'设 $S=\\{x\\in\\mathbb{R}\\mid x\\geq-1\\}$，$T=\\{x\\in\\mathbb{R}\\mid x\\geq0\\}$，$f:S\\to T$，$f(x)=\\sqrt{x+1}$。（1）说明 f 是否单射/满射；（2）f 是否有反函数，若有求之；（3）求 $f\\circ f$。', a:'（1）f 是双射。（2）$f^{-1}(x)=x^2-1$。（3）$(f\\circ f)(x)=\\sqrt{\\sqrt{x+1}+1}$。', explain:'开方函数在给定定义域上单调递增，故为双射，可求反函数。' },
    { level:'挑战', pointId:'P03020202', from:'教材自拟', kpName:'双射与反函数', q:'设 $f:A\\to B$，$g:B\\to A$，且 $g\\circ f=I_A$，$f\\circ g=I_B$。证明：f 是双射且 $g=f^{-1}$。', a:'先证 f 单射：若 $f(x_1)=f(x_2)$，两边作用 g 得 $g(f(x_1))=g(f(x_2))$，即 $x_1=x_2$。再证 f 满射：∀y∈B，取 $x=g(y)$，则 $f(x)=f(g(y))=y$。故 f 双射，且 g 是 f 的逆。', explain:'这是反函数的唯一性证明：左右逆同时存在时函数必双射，逆函数唯一。' }
  ]
},
'S0303': {
  analog: '基数=集合的「大小规格」；等势与优势是两种比大小工具，康托尔定理说明无穷也分层级，可数/不可数是第一道分水岭。',
  kps: {
    'K030301': {
      analog: '等势=「存在双射」=能建立一一对应。例：Z 与 Q 能排成一队与 N 对应，从而等势。',
      explain: '**等势（定义3.3.1）：**集合 $A$、$B$ 等势（$A\\approx B$）当且仅当存在双射 $f:A\\to B$。例3.3.1给出 $\\mathbb{Z}\\approx\\mathbb{N}$、$\\mathbb{N}\\approx\\mathbb{Q}$、$(0,1)\\approx\\mathbb{R}$、$[0,1]\\approx[a,b]$ 等。\n\n**幂集等势（例3.3.2）：**对任意集合 $A$ 有 $P(A)\\approx\\{0,1\\}^A$：令 $A\'\\mapsto\\chi_{A\'}$（特征函数）即得双射。\n\n**等势的性质（定理3.3.1）：**等势满足 ① $A\\approx A$；② $A\\approx B\\Rightarrow B\\approx A$；③ $A\\approx B$ 且 $B\\approx C\\Rightarrow A\\approx C$，即等势是等价关系。',
      chain: ['判断集合 A、B 大小', '构造双射 f:A→B（直接给一一对应）', 'P(A) 与 {0,1}^A 用特征函数建立双射', '等势满足自反、对称、传递（等价关系）']
    },
    'K030303': {
      analog: '康托尔定理 = 无限也有层级：实数和幂集比自然数「多」到无法枚举——用对角线造一个漏网之数。',
      explain: '**康托尔定理（定理3.3.2）：**① $\\mathbb{N}\\not\\approx\\mathbb{R}$；② 对任意集合 $A$ 都有 $A\\not\\approx P(A)$。\n\n**对角线法：**设 $f:\\mathbb{N}\\to[0,1]$ 为任意函数，把各 $f(n)$ 写成小数列成行，构造一个与每一行对角线数字都不同的新小数，它不在 $f$ 的值域中，故 $\\mathbb{N}\\to[0,1]$ 无满射，$\\mathbb{N}\\not\\approx\\mathbb{R}$。对 $A\\not\\approx P(A)$：若 $f:A\\to P(A)$ 是满射，令 $B=\\{x\\mid x\\in A\\land x\\notin f(x)\\}$，则 $B\\in P(A)$，存在 $b$ 使 $f(b)=B$，于是 $b\\in f(b)\\Leftrightarrow b\\notin f(b)$，矛盾。',
      chain: ['假设存在双射/满射', '把函数值列成行表，沿对角线取值构造反例元素', '新元素不在列表中 → 满射不存在', '结论：N≉R、A≉P(A)（基数严格变大）']
    },
    'K030302': {
      analog: '基数比较 = 「能放进去」就有大小关系：有单射 A→B 则 |A|≤|B|；双向都有单射即等势；ℵ0 是最小的无穷层级。',
      explain: '**优势（定义3.3.2）：**若存在单射 $A\\to B$，则称 $B$ 优势于 $A$，记 $A\\preccurlyeq\\cdot B$；若又不等势则记 $A\\prec B$。\n\n**用单射证明等势（定理3.3.3 及其应用）：**优势满足自反、传递；若 $A\\preccurlyeq\\cdot B$ 且 $B\\preccurlyeq\\cdot A$，则 $A\\approx B$，可用此法证明 $[0,1)\\approx\\{0,1\\}^{\\mathbb{N}}$ 之类的等势而免于直接构造双射。\n\n**有穷集与无穷集（定义3.3.3）：**空集或与某 $\\mathbb{N}_k$（$k\\ge1$）等势的集合为有穷集，否则为无穷集。\n\n**基数及其比较（定义3.3.4-3.3.5）：**有穷集 $A$ 的基数 $\\mathrm{card}\\,A$ 是与之等势的唯一 $\\mathbb{N}_k$；一般地 $\\mathrm{card}\\,A=\\mathrm{card}\\,B\\Leftrightarrow A\\approx B$，$\\mathrm{card}\\,A\\le\\mathrm{card}\\,B\\Leftrightarrow A\\preccurlyeq\\cdot B$。由康托尔定理 $\\mathrm{card}\\,A<\\mathrm{card}\\,P(A)$。\n\n**可数集（定义3.3.6）：**$\\mathrm{card}\\,A\\le\\aleph_0$ 的集合称为可数集：有限集、$\\mathbb{Z}$、$\\mathbb{Q}$ 可数，$\\mathbb{R}$、$P(\\mathbb{N})$ 不可数；可数集的任意子集仍可数，两个可数集及可数个可数集的并仍可数。',
      chain: ['看是否有单射 A→B（把 A「塞」进 B）', '双向单射 ⟹ 等势（避免直接构造双射）', '空集或与 ℕk 等势 → 有穷集；否则无穷', '用 card A ≤ ℵ0 判定可数集，做基数大小比较']
    }
  },
  questions: [
    { level:'基础', pointId:'P03030203', from:'教材自拟', kpName:'可数集', q:'说明整数集 $\\mathbb{Z}$ 是可数集，给出具体的双射 $f:\\mathbb{N}\\to\\mathbb{Z}$。', a:'$f(n)=\\begin{cases}n/2,&n\\text{为偶数}\\\\-(n+1)/2,&n\\text{为奇数}\\end{cases}$，即 $0\\to0,\\ 1\\to-1,\\ 2\\to1,\\ 3\\to-2,\\ 4\\to2,\\ldots$。', explain:'把整数「绕圈」排列成无限序列，即与自然数一一对应。' },
    { level:'进阶', pointId:'P03030201', from:'训练题库·模拟2', kpName:'函数集合基数', q:'$A=\\{a,b,c,d\\}$，$B=\\{0,1,2\\}$，则 $\\text{card}\\,B^A$=______。', a:'$|B^A|=|B|^{|A|}=3^4=81$。', explain:'函数集合基数公式 $|B^A|=|B|^{|A|}$。' },
    { level:'挑战', pointId:'P03030301', from:'训练题库·模拟3', kpName:'康托尔定理', q:'设 $A=\\{a,b\\}^\\mathbb{N}$，其中 $\\mathbb{N}$ 为自然数集，那么 $\\text{card}\\,A$=______。', a:'$2^{\\aleph_0}$（或 $\\aleph$）', explain:'无限长 0/1 序列全体与实数集等势，是不可数集；它与 P(ℕ) 等势。' }
  ]
}
});
